var class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model =
[
    [ "SaleListViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model.html#af91370cb1e5f566b4e1a0067ffaf64a7", null ],
    [ "CreateNewSaleWindow", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model.html#ad7ced422912c27855ae9283ad17e279f", null ],
    [ "DeleteSale", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model.html#af7e12bfd52be9a1507ea021b2b47bb99", null ],
    [ "UpdateList", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model.html#a3b0f2e06f1e0c602ed884b918faeb5cd", null ],
    [ "UpdateSaleWindow", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model.html#a1e868b9a9d94ebb233e196504d3eb56d", null ],
    [ "CanDeleteAndUpdate", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model.html#a3bb56ac5b089a174855bc2e07f1de95f", null ],
    [ "SaleViewModels", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model.html#a0f9ad6228828118cf5db72c7897efa7f", null ],
    [ "SelectedSale", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model.html#a0163f9e8b20f114cd76e5ed4c8beef8b", null ],
    [ "Status", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model.html#a3324ce31fca5095c7196f674884e3b89", null ],
    [ "PropertyChanged", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_list_view_model.html#ae35fd5a396bfa4d9514f9f6ee9cec805", null ]
];