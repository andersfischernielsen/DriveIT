var class_drive_i_t_1_1_models_1_1_comment_dto =
[
    [ "CarId", "class_drive_i_t_1_1_models_1_1_comment_dto.html#a18b18c11b3b9b0db59d1826a9851218f", null ],
    [ "CustomerId", "class_drive_i_t_1_1_models_1_1_comment_dto.html#af4ab396c3817ae47ab127e74e57bf935", null ],
    [ "Date", "class_drive_i_t_1_1_models_1_1_comment_dto.html#ab969d0d3a4cf8ee24f84b57cfa532dce", null ],
    [ "Description", "class_drive_i_t_1_1_models_1_1_comment_dto.html#a1dc99a74c3af6ca90f57c7d03022377a", null ],
    [ "Id", "class_drive_i_t_1_1_models_1_1_comment_dto.html#a2479f38040b86e9e810aecb23c59ec5d", null ],
    [ "Title", "class_drive_i_t_1_1_models_1_1_comment_dto.html#ac881c4bf5282b6401b3f1bce193b06ed", null ]
];