var class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model =
[
    [ "CustomerListViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model.html#a59e8cdb1459903bd37f39434935988a4", null ],
    [ "CreateNewCustomerWindow", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model.html#a8f3badf27e9785c5cde538aca19d45b8", null ],
    [ "DeleteCustomer", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model.html#af00eb6fccf76696d9ae3a9ea4451605d", null ],
    [ "UpdateCustomerWindow", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model.html#a417d7ab9d233b0b0e2d4cb9c0c874afc", null ],
    [ "UpdateList", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model.html#a4809577a116423fec6c356f3c2816c3a", null ],
    [ "CanDeleteAndUpdate", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model.html#a87957db068c729f740ec2e53c04f31f6", null ],
    [ "CustomerViewModels", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model.html#a4efb9586cfc156944d49fa9bbe05f095", null ],
    [ "SelectedCustomer", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model.html#ac15918c15989ec34d2d0539125241d2a", null ],
    [ "Status", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model.html#ad009f7b2ad2ba1c969707529ee16a730", null ],
    [ "PropertyChanged", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_list_view_model.html#ad763d289fc53ff21a55a26a754c5d59a", null ]
];