var class_drive_i_t_1_1_entity_framework_1_1_tests_1_1_entity_storage_tests =
[
    [ "CreateSaleTest", "class_drive_i_t_1_1_entity_framework_1_1_tests_1_1_entity_storage_tests.html#a08d63329a5b1308df89458f32f873e8d", null ],
    [ "GetAllSalesTest", "class_drive_i_t_1_1_entity_framework_1_1_tests_1_1_entity_storage_tests.html#a6e41476d6aae740392abc67f5b728c93", null ],
    [ "SetUp", "class_drive_i_t_1_1_entity_framework_1_1_tests_1_1_entity_storage_tests.html#ac0b4c06849e5557bb50f715629e6e270", null ]
];