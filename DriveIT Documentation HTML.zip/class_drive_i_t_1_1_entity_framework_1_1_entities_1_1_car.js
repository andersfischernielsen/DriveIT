var class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car =
[
    [ "Color", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a554aa67c427fef1892150a95cddb231e", null ],
    [ "Created", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a0be6a02caac0d0b3b63460d19e1b65b5", null ],
    [ "DistanceDriven", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a9930aa6c201829ada1a0bd312ca7fa38", null ],
    [ "Drive", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a61d674f1bbb467c69cf06e284f51536c", null ],
    [ "Fuel", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#ac00dec56cb5691c95e6bb0d8649d3c22", null ],
    [ "Id", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a946508b1da618da9da610cf4f7ebdd30", null ],
    [ "ImagePaths", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a386391b27c9e04c8364df551ecaaebb5", null ],
    [ "Make", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a79dedc591a1f769ae2fef3b8550f5778", null ],
    [ "Mileage", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#aee482b76875d7f88ec4332ffafddfcda", null ],
    [ "Model", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a5db283d3035dd0d248efdb2d04ac5375", null ],
    [ "NoughtTo100", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a31092077da77ee230ef4009145504c64", null ],
    [ "Price", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#ab4ad24fc7a6b52b19665dba6926dc590", null ],
    [ "Sold", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a5f8d2d0dba40e03dcc75fca825015209", null ],
    [ "TopSpeed", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a498f3780156629fda8be4ab4916192ec", null ],
    [ "Transmission", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a4966a9df68c04ee55f51ad9ad15ea364", null ],
    [ "Year", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_car.html#a3d00bb395be3c63f314a49ff58eda203", null ]
];