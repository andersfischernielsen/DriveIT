var class_drive_i_t_1_1_web_1_1_models_1_1_verify_phone_number_view_model =
[
    [ "Code", "class_drive_i_t_1_1_web_1_1_models_1_1_verify_phone_number_view_model.html#aa5949a0ceb186b06b7f0f4ec3804d45c", null ],
    [ "PhoneNumber", "class_drive_i_t_1_1_web_1_1_models_1_1_verify_phone_number_view_model.html#a4cd1f8804f9809fde11ff44e7a25bd57", null ]
];