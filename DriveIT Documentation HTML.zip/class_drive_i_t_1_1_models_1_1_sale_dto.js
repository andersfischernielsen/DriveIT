var class_drive_i_t_1_1_models_1_1_sale_dto =
[
    [ "CarId", "class_drive_i_t_1_1_models_1_1_sale_dto.html#aea0b5008980e04968dca298e34bc46c5", null ],
    [ "CustomerId", "class_drive_i_t_1_1_models_1_1_sale_dto.html#a1524544b86a8e6bd9240e77ed16e5103", null ],
    [ "EmployeeId", "class_drive_i_t_1_1_models_1_1_sale_dto.html#ad9d119496e170e221189e99fa145afb6", null ],
    [ "Id", "class_drive_i_t_1_1_models_1_1_sale_dto.html#a39c9a62887f7ba597acfba8d6e1eca66", null ],
    [ "Price", "class_drive_i_t_1_1_models_1_1_sale_dto.html#a136464132e8f43acaad2135f66750177", null ],
    [ "Sold", "class_drive_i_t_1_1_models_1_1_sale_dto.html#a8032cc92514a2ba07fe257a92b717839", null ]
];