var class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests =
[
    [ "Delete_NotFound", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#a59b359331b18f4f03e95d938fff3f3f6", null ],
    [ "Delete_Ok", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#af0edd7a6942479e95cd00007c7d24339", null ],
    [ "Get_2_Result", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#a7056fb7be1d0c20d677231d8a129899b", null ],
    [ "Get_NoParameters_ReturnsListOfCarDto_Count3", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#a69f798bee31213f04ea2e2d2a20d9b9c", null ],
    [ "Get_NoResult_MultipleCalls", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#ac1bd8bd5cbdfe033206c891f1c955358", null ],
    [ "GetFromUserId_Result", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#a503f76f6fd75ea270fb1d63d92e7ada6", null ],
    [ "Post_BadRequest", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#a8536ae51f9f0a707d11b255f60a30715", null ],
    [ "Post_Returns3", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#a0476837f69b89084e8d81a75bf36dbdc", null ],
    [ "Put_2_Success", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#a25b21f571b20044dfab3e87127eb7d26", null ],
    [ "Put_NotFound", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#a6c8afd10fb577097662fa4783c895378", null ],
    [ "SetUp", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#ab8937b5d9d0e603149af0b8b3c6d217c", null ],
    [ "TearDown", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_sales_controller_tests.html#a1b53fb7162261fccd77d5f3cfdfbf3f3", null ]
];