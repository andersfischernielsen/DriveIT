var class_drive_i_t_1_1_web_1_1_mvc_controllers_1_1_employee_controller =
[
    [ "Details", "class_drive_i_t_1_1_web_1_1_mvc_controllers_1_1_employee_controller.html#a956c6953cb89ef2da922194be4645e04", null ],
    [ "Index", "class_drive_i_t_1_1_web_1_1_mvc_controllers_1_1_employee_controller.html#a6fef7c45e6b1f69448324fdfd0a92dad", null ]
];