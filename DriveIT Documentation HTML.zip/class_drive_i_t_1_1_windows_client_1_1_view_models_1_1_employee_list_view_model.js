var class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model =
[
    [ "EmployeeListViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#a4315da21b12384aea84dd6827d8fc99b", null ],
    [ "CreateNewEmployeeWindow", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#a13ad3efc6ac1e5dd37fce89e9a6b3620", null ],
    [ "DeleteEmployee", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#a2be276aca970bbe685f8c6a911fd5221", null ],
    [ "UpdateEmployeeWindow", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#a607a8bac430001d34e111934cabd3f3f", null ],
    [ "UpdateList", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#a1faf16a8feebf0322e96c8ba9bc5f239", null ],
    [ "CanDelete", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#ad0105cb36860bf3507ef2bf09aad2816", null ],
    [ "CanUpdate", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#a191d68d404889a84bf8267686bba42da", null ],
    [ "EmployeeViewModels", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#acd7077d1eae01ab1beb3a64e994dd397", null ],
    [ "SelectedEmployee", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#aa85098bec6960adc41ce36b568ce5986", null ],
    [ "Status", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#a89bbae33193c6705667ff9b2c6767b9b", null ],
    [ "PropertyChanged", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_list_view_model.html#a4e268cb620ecc54a0742fa9344cab507", null ]
];