var class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model =
[
    [ "SaleEnum", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a89fef60a9c8099a5b3906e2af5ac8857", [
      [ "NotInSystem", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a89fef60a9c8099a5b3906e2af5ac8857aa52c8e468e5d9c78e231102542cf5a71", null ],
      [ "InSystem", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a89fef60a9c8099a5b3906e2af5ac8857a8d5ef8a07ad92ac1785bf6b2120b083c", null ]
    ] ],
    [ "SaleViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a2974a4647814e6d68f1d58e275097d2c", null ],
    [ "SaleViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#abd747320b25fce7a63298b795f12f8c9", null ],
    [ "CreateSale", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a04ee0975d1f4261e9b0906cd0d791876", null ],
    [ "DeleteSale", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a8a4ee32382c82ce2320cca71ea9f80f3", null ],
    [ "FindPriceBasedOnCar", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a7175efbdfa2b75328a75ad7b256379d8", null ],
    [ "SaveSale", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a52089e22c812188b251f27a7ead2c992", null ],
    [ "UpdateForeignKeyLists", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a629af22c68feefdf5f0caae7b2b2dfbf", null ],
    [ "UpdateSale", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#ae3bbb3b504f8538c67946f82e570696c", null ],
    [ "CarId", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a6bfb341bfc128c76bfaf71322ce65a13", null ],
    [ "CreateUpdateButtonText", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#afeb2cc1135bd4cae9623d3e509a70a32", null ],
    [ "CustomerId", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a1baed8049784ec5a6427db5c55b6aa98", null ],
    [ "EmployeeId", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#ac20506258d78e956a22b5a5a9ff80435", null ],
    [ "Price", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a803c82a9df9f5ed2105897f33157b6b1", null ],
    [ "SaleId", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a21556269b2dd0990dea55e756dc7ffa3", null ],
    [ "SaleState", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a1e6e3fcfc053a2266e7fd5880be1096a", null ],
    [ "Sold", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a51b692353f82d4908dc3be2e9b35330e", null ],
    [ "Status", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a5550e31931bb79ab87e95b371da8c1ee", null ],
    [ "PropertyChanged", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_sale_view_model.html#a4151c282e05e6e549638332477d25466", null ]
];