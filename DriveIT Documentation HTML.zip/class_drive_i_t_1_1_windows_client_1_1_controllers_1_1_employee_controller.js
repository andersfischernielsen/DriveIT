var class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_employee_controller =
[
    [ "CreateEmployee", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_employee_controller.html#a84c6d21b4a6adbfdee6db357e73d3d44", null ],
    [ "DeleteEmployee", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_employee_controller.html#ac4f42e80065196e7f9100e667a9aa24e", null ],
    [ "DeleteEmployee", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_employee_controller.html#a38e56d10b7410ed4f739e036e36ae154", null ],
    [ "ReadEmployee", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_employee_controller.html#a009da8833bcb0d83d226c14eae65b671", null ],
    [ "ReadEmployeeList", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_employee_controller.html#a41a0aa5bfb250361d7c337b8728cebc1", null ],
    [ "UpdateEmployee", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_employee_controller.html#adb1feb0643f96492c844d250e0fc9e24", null ]
];