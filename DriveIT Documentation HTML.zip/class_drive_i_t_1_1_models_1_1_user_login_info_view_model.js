var class_drive_i_t_1_1_models_1_1_user_login_info_view_model =
[
    [ "LoginProvider", "class_drive_i_t_1_1_models_1_1_user_login_info_view_model.html#a11ac44f917c5ee266b84d34bf3d4b526", null ],
    [ "ProviderKey", "class_drive_i_t_1_1_models_1_1_user_login_info_view_model.html#a53c68230c001111fb7760313d9c7773d", null ]
];