var class_path_reference_attribute =
[
    [ "PathReferenceAttribute", "class_path_reference_attribute.html#acc0edf7e4dd23ad0340083ddfdaa4cba", null ],
    [ "PathReferenceAttribute", "class_path_reference_attribute.html#a68daaaec94376b8e988ddcfd72229030", null ],
    [ "BasePath", "class_path_reference_attribute.html#ae6cf5aa92a7198b24c0656f974c3738d", null ]
];