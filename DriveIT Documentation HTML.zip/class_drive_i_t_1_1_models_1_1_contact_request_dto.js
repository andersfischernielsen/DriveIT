var class_drive_i_t_1_1_models_1_1_contact_request_dto =
[
    [ "CarId", "class_drive_i_t_1_1_models_1_1_contact_request_dto.html#a8c6b097213cf51fab560820bfd376360", null ],
    [ "CustomerId", "class_drive_i_t_1_1_models_1_1_contact_request_dto.html#a4cf18f723c2c7a4b851cfaaa8156a9d2", null ],
    [ "EmployeeId", "class_drive_i_t_1_1_models_1_1_contact_request_dto.html#ae618ee6a836e54e9e1f31ce7aafb602f", null ],
    [ "Id", "class_drive_i_t_1_1_models_1_1_contact_request_dto.html#a9d50e8acd1d2820816ac5a8566580fcb", null ],
    [ "Requested", "class_drive_i_t_1_1_models_1_1_contact_request_dto.html#a0d7f5191b913cad8052f836e2107fbfc", null ]
];