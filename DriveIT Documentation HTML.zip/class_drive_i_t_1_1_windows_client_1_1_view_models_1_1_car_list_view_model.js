var class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model =
[
    [ "CarListViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model.html#a450e3a59bd6a3bd2e493fc7bed373e61", null ],
    [ "CreateNewCarWindow", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model.html#a83f3b5c9e7545ba0dd3b83bbf87c039c", null ],
    [ "DeleteCar", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model.html#add4df3f5f0e6028fab38cc691a6e732a", null ],
    [ "UpdateCarWindow", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model.html#a073d6ef3aa5dc5636909968f4b5206a2", null ],
    [ "UpdateList", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model.html#ae01b4b08ade73652ace4e768510931e9", null ],
    [ "CanDeleteAndUpdate", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model.html#ad83664d3d6b7a68971872853664709e4", null ],
    [ "CarViewModels", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model.html#a3e0ca53b23baf1e98562f97ec3733c7b", null ],
    [ "SelectedCar", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model.html#afadc52c2b8624c7e2f649fdb4ee3f084", null ],
    [ "Status", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model.html#a4ea5ef03430deba8a27fb3dd52a18034", null ],
    [ "PropertyChanged", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_car_list_view_model.html#adb03834e8e2aa1ec3af4114029acd3b1", null ]
];