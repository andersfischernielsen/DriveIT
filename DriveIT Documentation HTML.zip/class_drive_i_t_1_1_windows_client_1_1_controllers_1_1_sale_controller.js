var class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_sale_controller =
[
    [ "SaleController", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_sale_controller.html#a81a44db716d93cfa9bfb7accc0b52700", null ],
    [ "CreateSale", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_sale_controller.html#a8c908735a811df8ac468be0394857293", null ],
    [ "DeleteSale", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_sale_controller.html#af6031a09ca80b6a6dfdf0f0617ce05f3", null ],
    [ "DeleteSale", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_sale_controller.html#aefdae00eacb9e7a098bf313811920207", null ],
    [ "ReadSale", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_sale_controller.html#ac97750bbd13ad44146c55057f559a387", null ],
    [ "ReadSaleList", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_sale_controller.html#a56d141b3fe277df664ee2b649cc6ccc2", null ],
    [ "UpdateSale", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_sale_controller.html#a0763c066d50d82ecbd6c4f969fb1ca26", null ]
];