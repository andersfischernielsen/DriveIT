var class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model =
[
    [ "CustomerEnum", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#acc8728d3668b94f3aca5bb4b01cfe5f3", [
      [ "NotInSystem", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#acc8728d3668b94f3aca5bb4b01cfe5f3aa52c8e468e5d9c78e231102542cf5a71", null ],
      [ "InSystem", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#acc8728d3668b94f3aca5bb4b01cfe5f3a8d5ef8a07ad92ac1785bf6b2120b083c", null ]
    ] ],
    [ "CustomerViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#ad8fb8b369341bfff1641fa7145857e3e", null ],
    [ "CustomerViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#ae3518efa812015236ec72d7a3b8c7b37", null ],
    [ "CreateCustomer", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#a28de341692445db5cb5d0bb7e7070035", null ],
    [ "DeleteCustomer", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#ae3be62212b03db6afccee935d6137c8e", null ],
    [ "SaveCustomer", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#a8afbec9c698f76e2bca7e99c05dffb4d", null ],
    [ "UpdateCustomer", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#a8e4bd305e7e9219d660aceda4d206ef5", null ],
    [ "CreateUpdateButtonText", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#a5fed125fa1f608e4e5609db3ac920fa6", null ],
    [ "CustomerId", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#a42e727861a4966284e8de945f3b91083", null ],
    [ "CustomerState", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#a402f051b02e1205a5b8b435ca8c3969b", null ],
    [ "Email", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#add2e270310008674996dba750ca830e1", null ],
    [ "FirstName", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#ace14c46f952934b357a7465f0b5ef405", null ],
    [ "GravatarLink", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#aba1d1b6debe1d95070eef20f624b04cf", null ],
    [ "LastName", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#a58364bb95282820790e721bcd3861b7d", null ],
    [ "Phone", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#a43af3a20009b5cc21fd84279e4c17240", null ],
    [ "Status", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#a291b14bb8e04d8a3c0cafceb759734bf", null ],
    [ "PropertyChanged", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_customer_view_model.html#ad56463b155f0d893e51ed07d6d5b48e6", null ]
];