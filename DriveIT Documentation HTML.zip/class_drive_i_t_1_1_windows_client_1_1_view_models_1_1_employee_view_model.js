var class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model =
[
    [ "EmployeeStateEnum", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#ab701238c803770dfb65a152ee3de0805", [
      [ "NotInSystem", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#ab701238c803770dfb65a152ee3de0805aa52c8e468e5d9c78e231102542cf5a71", null ],
      [ "InSystem", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#ab701238c803770dfb65a152ee3de0805a8d5ef8a07ad92ac1785bf6b2120b083c", null ]
    ] ],
    [ "EmployeeViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a1d0c35fe58e1fc9d8edcb8a52b866b56", null ],
    [ "EmployeeViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a49c65b7dc24547d271cc217292ec5bdf", null ],
    [ "CreateEmployee", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a3f916ff81f46548253c1da4cf211cf3a", null ],
    [ "DeleteEmployee", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#afe98db726e0b8d060ebb074f9e1c2562", null ],
    [ "SaveEmployee", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a9a780dd8dcf531cba18f2c7756cec187", null ],
    [ "UpdateEmployee", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a07bcc89ed2f9421314e0abc673bb1433", null ],
    [ "CanDeleteAndUpdate", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#ab0473ab3731e1b68f2b73afd7f5b6e2e", null ],
    [ "CreateUpdateButtonText", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a95402abc15cdce21e5a64f880f531664", null ],
    [ "Email", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a9c6be6b5435e76f857e4c91115f235e5", null ],
    [ "EmployeeId", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a438ce011d2b325fe3d84e0ed2cedfcfb", null ],
    [ "EmployeeState", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a6f51d18b7be200d337c35697fe70e551", null ],
    [ "FirstName", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#ac372e350d2299de97712d9e82b3d6963", null ],
    [ "GravatarLink", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#ae48360faec098fbe540d168f3121105f", null ],
    [ "JobTitle", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a51e180ba29ede898b90ada58d120950e", null ],
    [ "LastName", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a960d8e52c6ce64f2be1b577f3294c2c2", null ],
    [ "Phone", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#ae6e436bfbbfd4b1168d995067132b132", null ],
    [ "Status", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#ac521a1875845d7e36caa2f40b7ccf413", null ],
    [ "PropertyChanged", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_view_model.html#a5c2691db1d6f111b9ec172e6b93bc35c", null ]
];