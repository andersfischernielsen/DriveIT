var class_drive_i_t_1_1_web_1_1_models_1_1_set_password_view_model =
[
    [ "ConfirmPassword", "class_drive_i_t_1_1_web_1_1_models_1_1_set_password_view_model.html#ad7770f44b3df5c0abcf3afc76cdd3e76", null ],
    [ "NewPassword", "class_drive_i_t_1_1_web_1_1_models_1_1_set_password_view_model.html#a17cf088a0f0ed258fb07a3a7bfb362dd", null ]
];