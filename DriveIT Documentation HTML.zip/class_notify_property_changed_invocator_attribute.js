var class_notify_property_changed_invocator_attribute =
[
    [ "NotifyPropertyChangedInvocatorAttribute", "class_notify_property_changed_invocator_attribute.html#a74986b0d8e8b310ba92cd038ca58771f", null ],
    [ "NotifyPropertyChangedInvocatorAttribute", "class_notify_property_changed_invocator_attribute.html#a53ea804fe542cdfff5c0ffbb47fdaeb0", null ],
    [ "ParameterName", "class_notify_property_changed_invocator_attribute.html#a156a54b467974741191e07b4812442ac", null ]
];