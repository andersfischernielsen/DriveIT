var class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model =
[
    [ "EmployeeDetailsViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model.html#abc4594d3a79d7a5443283dac434addc7", null ],
    [ "EmployeeDetailsViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model.html#a4bcb5434a6f54ec0a6b010973769ddfa", null ],
    [ "BestSellingEmployee", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model.html#ada5d11eec00ff12df7fbc330e3b7e372", null ],
    [ "Email", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model.html#a2692567a22da06ad62a51cb48f197b21", null ],
    [ "FirstName", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model.html#afa70927676289e692d21530d7599d4fd", null ],
    [ "GravatarLink", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model.html#ab612becb6f7fcb4404ad8eeac3ba1253", null ],
    [ "JobTitle", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model.html#acf853886ce276a8ab049ba039f40aa0c", null ],
    [ "LastName", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model.html#afc410939ef38d29c3c4876e9d2f9bc70", null ],
    [ "Phone", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model.html#a37745b4e27e2fb6d914b3437e235d3a6", null ],
    [ "PropertyChanged", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_employee_details_view_model.html#ab43affae823a6530f945dc4eeab037ba", null ]
];