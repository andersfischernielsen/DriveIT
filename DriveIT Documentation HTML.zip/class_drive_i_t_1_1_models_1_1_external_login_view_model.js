var class_drive_i_t_1_1_models_1_1_external_login_view_model =
[
    [ "Name", "class_drive_i_t_1_1_models_1_1_external_login_view_model.html#a1d891e49f577f9ae8310f41774fbc580", null ],
    [ "State", "class_drive_i_t_1_1_models_1_1_external_login_view_model.html#a051f25823f6214e2b88258511b37ea1c", null ],
    [ "Url", "class_drive_i_t_1_1_models_1_1_external_login_view_model.html#a3f7957c917a194aaa76a21973b2b7481", null ]
];