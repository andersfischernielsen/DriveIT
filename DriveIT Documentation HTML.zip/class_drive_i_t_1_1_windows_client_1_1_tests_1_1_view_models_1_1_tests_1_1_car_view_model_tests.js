var class_drive_i_t_1_1_windows_client_1_1_tests_1_1_view_models_1_1_tests_1_1_car_view_model_tests =
[
    [ "AddPictures", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_view_models_1_1_tests_1_1_car_view_model_tests.html#af0f4add180acf4e644c2a86fe3711046", null ],
    [ "DeleteOneOfTwoPictures", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_view_models_1_1_tests_1_1_car_view_model_tests.html#ac8adb578fcab9415f4144d374e6831f4", null ],
    [ "DeleteOnlyPicture", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_view_models_1_1_tests_1_1_car_view_model_tests.html#a49c1934eebbdd063dfd3126d61a679ee", null ],
    [ "NextPictureWithOnePicture", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_view_models_1_1_tests_1_1_car_view_model_tests.html#a22b0c51eba65a5830c20851c6a1175b3", null ],
    [ "NextPictureWithThreePicture", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_view_models_1_1_tests_1_1_car_view_model_tests.html#a5ccb065085ad61740b478c88a04dfaa1", null ],
    [ "NextPictureWithTwoPicture", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_view_models_1_1_tests_1_1_car_view_model_tests.html#af72a1986d317efdeace6d3a0222c6c31", null ],
    [ "PreviousPictureWithOnePicture", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_view_models_1_1_tests_1_1_car_view_model_tests.html#a7ded2503ebf450f63a92dd3e27635f25", null ],
    [ "PreviousPictureWithThreePicture", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_view_models_1_1_tests_1_1_car_view_model_tests.html#a56d900cd4f984f6385e7d7f0f5f3fd72", null ],
    [ "PreviousPictureWithTwoPicture", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_view_models_1_1_tests_1_1_car_view_model_tests.html#a12f4be0d420cf595e93fdcf3974c25cb", null ]
];