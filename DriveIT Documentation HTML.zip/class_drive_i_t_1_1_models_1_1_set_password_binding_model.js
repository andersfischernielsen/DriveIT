var class_drive_i_t_1_1_models_1_1_set_password_binding_model =
[
    [ "ConfirmPassword", "class_drive_i_t_1_1_models_1_1_set_password_binding_model.html#a03d2ce722142d46fa9fadd0b71396010", null ],
    [ "NewPassword", "class_drive_i_t_1_1_models_1_1_set_password_binding_model.html#a79a6fa01474a82b09b6e61bc7e8838cb", null ]
];