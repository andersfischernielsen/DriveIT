var class_drive_i_t_1_1_models_1_1_employee_dto =
[
    [ "Email", "class_drive_i_t_1_1_models_1_1_employee_dto.html#a331ca52fb12335e104bd337b35910dd2", null ],
    [ "FirstName", "class_drive_i_t_1_1_models_1_1_employee_dto.html#af2f23e587cfe77e3c7f3dd98df5c1a3c", null ],
    [ "Id", "class_drive_i_t_1_1_models_1_1_employee_dto.html#a0c72012c8158ee6b18d98af13c3e6ac4", null ],
    [ "JobTitle", "class_drive_i_t_1_1_models_1_1_employee_dto.html#a0d03dc03a02d25d3a02a4a6c87009e8c", null ],
    [ "LastName", "class_drive_i_t_1_1_models_1_1_employee_dto.html#afb3149aca65786e29c89d0e36c343c5a", null ],
    [ "Phone", "class_drive_i_t_1_1_models_1_1_employee_dto.html#a5cf7a6f8f71a6eaca5cb9579e004e8a0", null ]
];