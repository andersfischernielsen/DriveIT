var class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_sale =
[
    [ "Car", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_sale.html#accb2e326cf382c9f4913615a0d04a1ad", null ],
    [ "CarId", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_sale.html#a2dab4022f4268c495e57156a0610f893", null ],
    [ "Customer", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_sale.html#a94911084161a0a18d3d2eb0efb7fe034", null ],
    [ "CustomerId", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_sale.html#a5e4b8fc5e1a2735d3609f470c36d4162", null ],
    [ "DateOfSale", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_sale.html#a1634a85504c54a8422acc83f360fcbcf", null ],
    [ "Employee", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_sale.html#abc1bda70931d5d1e76ac3d7a4c916d65", null ],
    [ "EmployeeId", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_sale.html#a94b3b3461e29d7b984b97204eb71e34f", null ],
    [ "Id", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_sale.html#a870774bc8cbfc5c45747d67c16c63ff0", null ],
    [ "Price", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_sale.html#a3bb980cb83073524ea1c4bb4b9394735", null ]
];