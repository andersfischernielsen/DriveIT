var class_drive_i_t_1_1_web_1_1_api_controllers_1_1_sales_controller =
[
    [ "SalesController", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_sales_controller.html#a1dad205b5114e6ee00566ac6249e9cce", null ],
    [ "SalesController", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_sales_controller.html#a1a596a72a1b3b7c35f290f2a06a58c88", null ],
    [ "Delete", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_sales_controller.html#af3d731b56bfd025a28d5a085dbb98dbf", null ],
    [ "Get", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_sales_controller.html#a79cbdcc8226e9d2f5431b6a4bf738108", null ],
    [ "Get", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_sales_controller.html#a2fb1c3ff46e46bbbac2738eb64dd6bb7", null ],
    [ "GetFromCustomerId", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_sales_controller.html#a6094ac69b4c2b4a726e6a286c4363903", null ],
    [ "Post", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_sales_controller.html#afa3b6fc35e7b36554d334581b58da326", null ],
    [ "Put", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_sales_controller.html#a49990de11d3483b03df93f391fe71e97", null ]
];