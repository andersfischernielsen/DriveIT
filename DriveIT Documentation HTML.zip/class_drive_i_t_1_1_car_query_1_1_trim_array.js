var class_drive_i_t_1_1_car_query_1_1_trim_array =
[
    [ "Trims", "class_drive_i_t_1_1_car_query_1_1_trim_array.html#a740b6c4d9fa14926cf7a348b884ea554", null ]
];