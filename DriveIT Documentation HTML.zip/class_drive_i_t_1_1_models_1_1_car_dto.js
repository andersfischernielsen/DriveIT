var class_drive_i_t_1_1_models_1_1_car_dto =
[
    [ "Color", "class_drive_i_t_1_1_models_1_1_car_dto.html#a662858022cb6d1aaa25246096a61a6f9", null ],
    [ "Created", "class_drive_i_t_1_1_models_1_1_car_dto.html#a23948ac69db851930a8c70b8f9c794c1", null ],
    [ "DistanceDriven", "class_drive_i_t_1_1_models_1_1_car_dto.html#adfe79d5cf0564395fb55ab28bb01fc30", null ],
    [ "Drive", "class_drive_i_t_1_1_models_1_1_car_dto.html#a473b54ebe8969ebc9b363a98ff9904e9", null ],
    [ "Fuel", "class_drive_i_t_1_1_models_1_1_car_dto.html#a3b2ca182d1502e42cce26f98b844ea0c", null ],
    [ "Id", "class_drive_i_t_1_1_models_1_1_car_dto.html#a811647d6de4f1347c90686e7f331b349", null ],
    [ "ImagePaths", "class_drive_i_t_1_1_models_1_1_car_dto.html#a3d33a9197e83cb812dddca282db3de40", null ],
    [ "Make", "class_drive_i_t_1_1_models_1_1_car_dto.html#a4c8a5024ecc15a9581b1d383c7d611b2", null ],
    [ "Mileage", "class_drive_i_t_1_1_models_1_1_car_dto.html#a1c8c4532dc62ab9beb24aaa3e2035bc9", null ],
    [ "Model", "class_drive_i_t_1_1_models_1_1_car_dto.html#a1eadcd0d0dfa3b856e9774572ef351c9", null ],
    [ "NoughtTo100", "class_drive_i_t_1_1_models_1_1_car_dto.html#a619ed6f2142b9bf03a659cf4c97ffc91", null ],
    [ "Price", "class_drive_i_t_1_1_models_1_1_car_dto.html#aabba785181aed21227668db6c6d9a1ae", null ],
    [ "Sold", "class_drive_i_t_1_1_models_1_1_car_dto.html#a864f950f44c1532d4e7c04b903994326", null ],
    [ "TopSpeed", "class_drive_i_t_1_1_models_1_1_car_dto.html#a37727ff02e16e322de40180a7506dd3c", null ],
    [ "Transmission", "class_drive_i_t_1_1_models_1_1_car_dto.html#aa0644fe397b64ccf2defb44bce057068", null ],
    [ "Year", "class_drive_i_t_1_1_models_1_1_car_dto.html#ad356e910cb28c89638d65609170a2304", null ]
];