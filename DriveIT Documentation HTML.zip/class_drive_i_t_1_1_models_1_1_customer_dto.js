var class_drive_i_t_1_1_models_1_1_customer_dto =
[
    [ "Email", "class_drive_i_t_1_1_models_1_1_customer_dto.html#a9ca97c6afeb6876dbc0eaf0dc3d2bed8", null ],
    [ "FirstName", "class_drive_i_t_1_1_models_1_1_customer_dto.html#a14e4fe6926b32023a11069f1ff3d774b", null ],
    [ "Id", "class_drive_i_t_1_1_models_1_1_customer_dto.html#a3f7827d9d1ad48a8e25080d50ea1e7bc", null ],
    [ "LastName", "class_drive_i_t_1_1_models_1_1_customer_dto.html#a1a04bb7eb8d21e511e44d2ba039c0114", null ],
    [ "Phone", "class_drive_i_t_1_1_models_1_1_customer_dto.html#ac263d216a49ab6a3d7ae30acdacc4aeb", null ]
];