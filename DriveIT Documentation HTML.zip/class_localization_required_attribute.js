var class_localization_required_attribute =
[
    [ "LocalizationRequiredAttribute", "class_localization_required_attribute.html#aa2b3c3c66137921e96fd08310066c914", null ],
    [ "LocalizationRequiredAttribute", "class_localization_required_attribute.html#a7d6235d2f8883d6f6311ca2a95156a9c", null ],
    [ "Required", "class_localization_required_attribute.html#af8b46c34356964b9b15c22c7e5113d23", null ]
];