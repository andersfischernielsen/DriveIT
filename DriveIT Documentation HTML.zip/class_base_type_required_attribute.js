var class_base_type_required_attribute =
[
    [ "BaseTypeRequiredAttribute", "class_base_type_required_attribute.html#a3b535405fd33291328613b6ede4e5d8a", null ],
    [ "BaseType", "class_base_type_required_attribute.html#abd32451b36cd8eff34ecee4718e78f5b", null ]
];