var class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_customer_controller =
[
    [ "CustomerController", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_customer_controller.html#ad02c3937242e3f6971ab7293c6b7b4eb", null ],
    [ "CreateCustomer", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_customer_controller.html#ab15045bad5ecfda756b3287e691ff451", null ],
    [ "DeleteCustomer", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_customer_controller.html#a60bd466b6019629875cc6e0ebe3d91dc", null ],
    [ "DeleteCustomer", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_customer_controller.html#a5b5bff646d166f5fa3c350ed9a19f937", null ],
    [ "ReadCustomer", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_customer_controller.html#a8c16ec5446242651e1597d383e3adcb4", null ],
    [ "ReadCustomerList", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_customer_controller.html#a4b843f11cf430f25b0aa07e99bb45b80", null ],
    [ "UpdateCustomer", "class_drive_i_t_1_1_windows_client_1_1_controllers_1_1_customer_controller.html#ac17cdfbd9e84ccdd42fbfc3c2e333158", null ]
];