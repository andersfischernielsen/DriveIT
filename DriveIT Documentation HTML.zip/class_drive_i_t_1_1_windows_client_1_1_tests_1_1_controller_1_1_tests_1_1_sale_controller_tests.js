var class_drive_i_t_1_1_windows_client_1_1_tests_1_1_controller_1_1_tests_1_1_sale_controller_tests =
[
    [ "TestCreateSale", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_controller_1_1_tests_1_1_sale_controller_tests.html#a927c7a4c9a3093be554891f57971f6f8", null ],
    [ "TestDeleteSale", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_controller_1_1_tests_1_1_sale_controller_tests.html#ab60a57626db99c9561e4a5e746f229c2", null ],
    [ "TestFixtureSetUp", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_controller_1_1_tests_1_1_sale_controller_tests.html#a523f51d6dadc2f516a426dc2a52ebc4e", null ],
    [ "TestFixtureTearDown", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_controller_1_1_tests_1_1_sale_controller_tests.html#afa6e0f206d943878c15a6117e568b129", null ],
    [ "TestUpdateSale", "class_drive_i_t_1_1_windows_client_1_1_tests_1_1_controller_1_1_tests_1_1_sale_controller_tests.html#a6976217c40aca46bee37fef246e2693c", null ]
];