var class_drive_i_t_1_1_web_1_1_models_1_1_configure_two_factor_view_model =
[
    [ "Providers", "class_drive_i_t_1_1_web_1_1_models_1_1_configure_two_factor_view_model.html#afbed460061bd50693e0ef3c0226b2e7e", null ],
    [ "SelectedProvider", "class_drive_i_t_1_1_web_1_1_models_1_1_configure_two_factor_view_model.html#a803b85493540af0e20447ee58e2c48b6", null ]
];