var class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_main_view_view_model =
[
    [ "MainViewViewModel", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_main_view_view_model.html#aceee05ea2c63e01d642798889b0a2ef6", null ],
    [ "TabIndex", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_main_view_view_model.html#aa3d1471b9828b405f1eb1954f5830774", null ],
    [ "PropertyChanged", "class_drive_i_t_1_1_windows_client_1_1_view_models_1_1_main_view_view_model.html#a1bb6c5df4c5487f35029b2b7ac7809c0", null ]
];