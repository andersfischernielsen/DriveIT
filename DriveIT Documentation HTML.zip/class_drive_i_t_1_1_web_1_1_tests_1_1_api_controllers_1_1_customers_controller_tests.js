var class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_customers_controller_tests =
[
    [ "Delete_NotFound", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_customers_controller_tests.html#a8cd3e31718128ddbffe85391e8510eba", null ],
    [ "Delete_Ok", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_customers_controller_tests.html#a4ef6b21d96658022c9e3e788a046b4d4", null ],
    [ "Get_NoResult_MultipleCalls", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_customers_controller_tests.html#a57dec6397fcd191ede3a6fd80d5b2e9a", null ],
    [ "Get_ReturnsListOfCustomerDto_Count2", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_customers_controller_tests.html#af0fc8dd0aaddeb4c4c32edcca5b14874", null ],
    [ "Put_NotFound", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_customers_controller_tests.html#aef7762953ccaf769425c5daaaace94de", null ],
    [ "Put_Success", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_customers_controller_tests.html#a6ca97b9d94cefbcda714ab8fc03f7cda", null ],
    [ "SetUp", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_customers_controller_tests.html#afd6b0b17c5b4a7eeeae51adf8b8c8e1f", null ],
    [ "TearDown", "class_drive_i_t_1_1_web_1_1_tests_1_1_api_controllers_1_1_customers_controller_tests.html#a12bf638ad801413ce0d774a5196ed8d2", null ]
];