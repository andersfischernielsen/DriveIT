var class_drive_i_t_1_1_web_1_1_api_controllers_1_1_comments_controller =
[
    [ "CommentsController", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_comments_controller.html#afcbd26b848de0ef6d85eda436239b8ff", null ],
    [ "CommentsController", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_comments_controller.html#a71012b4086d34e39d616c784eb665594", null ],
    [ "Delete", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_comments_controller.html#a2e3c9caaa7ca4049490cd7f43aa1ebe0", null ],
    [ "GetByCarId", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_comments_controller.html#a84b9da1af4864f1b012109ae45fe2891", null ],
    [ "GetByCommentId", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_comments_controller.html#a86d40bfe1a07f56a0124d2e5d8c8bc40", null ],
    [ "Post", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_comments_controller.html#a77b4877749a8c14a543712861a77ae02", null ],
    [ "Put", "class_drive_i_t_1_1_web_1_1_api_controllers_1_1_comments_controller.html#a44607991a55b3a6476db0b64f3a61cea", null ]
];