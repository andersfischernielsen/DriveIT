var class_drive_i_t_1_1_web_1_1_models_1_1_manage_logins_view_model =
[
    [ "CurrentLogins", "class_drive_i_t_1_1_web_1_1_models_1_1_manage_logins_view_model.html#a32ed8cc5258075aee5a70f05c561ecc5", null ],
    [ "OtherLogins", "class_drive_i_t_1_1_web_1_1_models_1_1_manage_logins_view_model.html#ab19d33f08d12ff99c8b9bc5e7e581a69", null ]
];