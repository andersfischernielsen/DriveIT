var class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_image_path =
[
    [ "Car", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_image_path.html#ac515e192ff6c82389bda7b5027ac79eb", null ],
    [ "CarId", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_image_path.html#a9422d7d21d8afe344a89f091e57666a4", null ],
    [ "Path", "class_drive_i_t_1_1_entity_framework_1_1_entities_1_1_image_path.html#a358081cb62e906ca70bf37cadbb94c44", null ]
];